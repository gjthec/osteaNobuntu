import {
  require_moment
} from "./chunk-V6ZVUDCJ.js";
import "./chunk-AJH3MT3R.js";
export default require_moment();
//# sourceMappingURL=moment.js.map
