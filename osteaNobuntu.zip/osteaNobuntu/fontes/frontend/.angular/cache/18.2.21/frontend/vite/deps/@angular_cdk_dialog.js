import {
  CdkDialogContainer,
  DEFAULT_DIALOG_CONFIG,
  DIALOG_DATA,
  DIALOG_SCROLL_STRATEGY,
  DIALOG_SCROLL_STRATEGY_PROVIDER,
  DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY,
  Dialog,
  DialogConfig,
  DialogModule,
  DialogRef,
  throwDialogContentAlreadyAttachedError
} from "./chunk-UYOFMDP6.js";
import "./chunk-SSQVX5ZX.js";
import "./chunk-E6ZDMYT2.js";
import "./chunk-BAZ2YJHM.js";
import "./chunk-342NVLMZ.js";
import "./chunk-B5SIYYLN.js";
import "./chunk-X7S6Z27T.js";
import "./chunk-DWV2Z3H4.js";
import "./chunk-DCK2C627.js";
import "./chunk-RNE2ZHW2.js";
import "./chunk-EU5Y5G3A.js";
import "./chunk-XDGTZPR5.js";
import "./chunk-AJH3MT3R.js";
export {
  CdkDialogContainer,
  DEFAULT_DIALOG_CONFIG,
  DIALOG_DATA,
  DIALOG_SCROLL_STRATEGY,
  DIALOG_SCROLL_STRATEGY_PROVIDER,
  DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY,
  Dialog,
  DialogConfig,
  DialogModule,
  DialogRef,
  throwDialogContentAlreadyAttachedError
};
//# sourceMappingURL=@angular_cdk_dialog.js.map
