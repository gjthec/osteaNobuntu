import {
  BrowserPerformanceMeasurement
} from "./chunk-NOVEMMWR.js";
import "./chunk-AJH3MT3R.js";
export {
  BrowserPerformanceMeasurement
};
//# sourceMappingURL=BrowserPerformanceMeasurement-5CYTHV27.js.map
