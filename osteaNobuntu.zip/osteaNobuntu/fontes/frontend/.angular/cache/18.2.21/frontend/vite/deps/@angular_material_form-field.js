import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
} from "./chunk-JALI53GE.js";
import "./chunk-QODE3W54.js";
import "./chunk-FHOZ22WC.js";
import "./chunk-HVLD3HIO.js";
import "./chunk-B5SIYYLN.js";
import "./chunk-X7S6Z27T.js";
import "./chunk-DWV2Z3H4.js";
import "./chunk-DCK2C627.js";
import "./chunk-RNE2ZHW2.js";
import "./chunk-EU5Y5G3A.js";
import "./chunk-XDGTZPR5.js";
import "./chunk-AJH3MT3R.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
};
//# sourceMappingURL=@angular_material_form-field.js.map
