import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-FYRYO244.js";
import "./chunk-BJM5J7F4.js";
import "./chunk-AMD5IM3Z.js";
import "./chunk-HVLD3HIO.js";
import "./chunk-B5SIYYLN.js";
import "./chunk-X7S6Z27T.js";
import "./chunk-DWV2Z3H4.js";
import "./chunk-DCK2C627.js";
import "./chunk-RNE2ZHW2.js";
import "./chunk-EU5Y5G3A.js";
import "./chunk-XDGTZPR5.js";
import "./chunk-AJH3MT3R.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
//# sourceMappingURL=@angular_material_icon.js.map
