import {
  require_moment
} from "./chunk-V6ZVUDCJ.js";
import {
  __commonJS,
  __require
} from "./chunk-AJH3MT3R.js";

// node_modules/moment/locale/pt-br.js
var require_pt_br = __commonJS({
  "node_modules/moment/locale/pt-br.js"(exports, module) {
    (function(global, factory) {
      typeof exports === "object" && typeof module !== "undefined" && typeof __require === "function" ? factory(require_moment()) : typeof define === "function" && define.amd ? define(["../moment"], factory) : factory(global.moment);
    })(exports, function(moment) {
      "use strict";
      var ptBr = moment.defineLocale("pt-br", {
        months: "janeiro_fevereiro_março_abril_maio_junho_julho_agosto_setembro_outubro_novembro_dezembro".split("_"),
        monthsShort: "jan_fev_mar_abr_mai_jun_jul_ago_set_out_nov_dez".split("_"),
        weekdays: "domingo_segunda-feira_terça-feira_quarta-feira_quinta-feira_sexta-feira_sábado".split("_"),
        weekdaysShort: "dom_seg_ter_qua_qui_sex_sáb".split("_"),
        weekdaysMin: "do_2ª_3ª_4ª_5ª_6ª_sá".split("_"),
        weekdaysParseExact: true,
        longDateFormat: {
          LT: "HH:mm",
          LTS: "HH:mm:ss",
          L: "DD/MM/YYYY",
          LL: "D [de] MMMM [de] YYYY",
          LLL: "D [de] MMMM [de] YYYY [às] HH:mm",
          LLLL: "dddd, D [de] MMMM [de] YYYY [às] HH:mm"
        },
        calendar: {
          sameDay: "[Hoje às] LT",
          nextDay: "[Amanhã às] LT",
          nextWeek: "dddd [às] LT",
          lastDay: "[Ontem às] LT",
          lastWeek: function() {
            return this.day() === 0 || this.day() === 6 ? "[Último] dddd [às] LT" : "[Última] dddd [às] LT";
          },
          sameElse: "L"
        },
        relativeTime: {
          future: "em %s",
          past: "há %s",
          s: "poucos segundos",
          ss: "%d segundos",
          m: "um minuto",
          mm: "%d minutos",
          h: "uma hora",
          hh: "%d horas",
          d: "um dia",
          dd: "%d dias",
          M: "um mês",
          MM: "%d meses",
          y: "um ano",
          yy: "%d anos"
        },
        dayOfMonthOrdinalParse: /\d{1,2}º/,
        ordinal: "%dº",
        invalidDate: "Data inválida"
      });
      return ptBr;
    });
  }
});
export default require_pt_br();
/*! Bundled license information:

moment/locale/pt-br.js:
  (*! moment.js locale configuration *)
  (*! locale : Portuguese (Brazil) [pt-br] *)
  (*! author : Caio Ribeiro Pereira : https://github.com/caio-ribeiro-pereira *)
*/
//# sourceMappingURL=moment_locale_pt-br.js.map
