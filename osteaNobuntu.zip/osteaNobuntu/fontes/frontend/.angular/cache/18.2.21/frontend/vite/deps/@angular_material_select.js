import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-BLUGZE2Q.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-JALI53GE.js";
import "./chunk-QODE3W54.js";
import "./chunk-FHOZ22WC.js";
import "./chunk-SSQVX5ZX.js";
import "./chunk-E6ZDMYT2.js";
import "./chunk-BAZ2YJHM.js";
import "./chunk-342NVLMZ.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-HVLD3HIO.js";
import "./chunk-B5SIYYLN.js";
import "./chunk-X7S6Z27T.js";
import "./chunk-HAPOX4IY.js";
import "./chunk-DWV2Z3H4.js";
import "./chunk-DCK2C627.js";
import "./chunk-RNE2ZHW2.js";
import "./chunk-EU5Y5G3A.js";
import "./chunk-XDGTZPR5.js";
import "./chunk-AJH3MT3R.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
