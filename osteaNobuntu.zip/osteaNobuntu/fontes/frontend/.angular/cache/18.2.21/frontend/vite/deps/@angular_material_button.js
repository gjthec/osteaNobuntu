import {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-QCBLD7GK.js";
import "./chunk-HVLD3HIO.js";
import "./chunk-B5SIYYLN.js";
import "./chunk-X7S6Z27T.js";
import "./chunk-DWV2Z3H4.js";
import "./chunk-DCK2C627.js";
import "./chunk-RNE2ZHW2.js";
import "./chunk-EU5Y5G3A.js";
import "./chunk-XDGTZPR5.js";
import "./chunk-AJH3MT3R.js";
export {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
